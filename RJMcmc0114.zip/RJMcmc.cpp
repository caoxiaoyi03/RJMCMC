// RJMcmc.cpp : Defines the entry point for the console application.
//
#include <iostream>
#include <iomanip>
#include <vector>
#include <fstream>
#include "Matrix.h"
#include "ClusterFlags.h"
#include "mcmc.h"
#include "Random.h"
#include "MCMCEnv.h"

using namespace std;


// With a new dataset, do not forget modify n_clusterhome!!!

void initializeParameters(const matrix &Data) {
	matrix mu1(1,3);
	matrix mu0(1,3);
	matrix sigma0(3,1.0,1);
	matrix sigma1(3,1.0,1);
	double beta0 = 1000.0;
	double beta1 = 1000.0;
	double deltar = 3.0;
	double alpha = 1.0;
	double shape = 1.0;
	double bk = 0.5; // For split_merge move and birth_death move, we give equal probability.
	double ranc  = 0.9; // Tail birth is given much more porbability.
	double k1 = 10.0;
	double k0 = 10.0;
	// K1 and deltar are both used to control data effect, it should be 
	// Note that K1 must be <= 1;
	// With a large or small K1, the algorithm both seems converge very slowly.
	mu1 = Data.matrix_mean();
	mu0 = mu1;
	sigma1 *= 1.0/k1;
	sigma0 *= 1.0/k0;

	// Beta controls the prior effect to the sampling probability
	// A large Beta value should be set, if you want to decrease the prior effect.
	// The data effect is controlled by deltar, if you want to increase data effect, a large deltar should be set.
	// However the minimum of 

	MCMCEnv::initializeParameters(mu1, mu0, sigma1, sigma0, beta1, beta0, deltar, alpha, shape, bk, ranc);

}

int main(int argc, char* argv[])
{   

	long i,j,k,l;
	long n_time = 5;
	long n_gene = 3;
	long n_num = 90;
	// The cell number in each time point
	vector <unsigned long> n_Nt(n_time);
	// Genes relating to clustering(1) and not relating to clustering(0).
	vector <bool> n_tao(n_gene, true);
	vector <bool> newtao(n_gene, false);
	// Cluster number in each time point.
	vector <long> n_clusternum(n_time);

	n_Nt.at(0) = 10;
	n_Nt.at(1) = 20;
	n_Nt.at(2) = 20;
	n_Nt.at(3) = 20;
	n_Nt.at(4) = 20;

	n_tao.at(0) = true;
	n_tao.at(1) = true;
	n_tao.at(2) = true;


	n_clusternum.at(0) = 1;
	n_clusternum.at(1) = 1;
	n_clusternum.at(2) = 1;
	n_clusternum.at(3) = 1;
	n_clusternum.at(4) = 1;

	ClusterFlags n_z(n_time, n_Nt);

	// Note that n_z must be set according to tree value.
	n_z.setFlag(0,0,1);
	n_z.setFlag(0,1,1);
	n_z.setFlag(0,2,1);
	n_z.setFlag(0,3,1);
	n_z.setFlag(0,4,1);
	n_z.setFlag(0,5,1);
	n_z.setFlag(0,6,1);
	n_z.setFlag(0,7,1);
	n_z.setFlag(0,8,1);
	n_z.setFlag(0,9,1);


	n_z.setFlag(1,0,1);
	n_z.setFlag(1,1,1);
	n_z.setFlag(1,2,1);
	n_z.setFlag(1,3,1);
	n_z.setFlag(1,4,1);
	n_z.setFlag(1,5,1);
	n_z.setFlag(1,6,1);
	n_z.setFlag(1,7,1);
	n_z.setFlag(1,8,1);
	n_z.setFlag(1,9,1);
	n_z.setFlag(1,10,1);
	n_z.setFlag(1,11,1);
	n_z.setFlag(1,12,1);
	n_z.setFlag(1,13,1);
	n_z.setFlag(1,14,1);
	n_z.setFlag(1,15,1);
	n_z.setFlag(1,16,1);
	n_z.setFlag(1,17,1);
	n_z.setFlag(1,18,1);
	n_z.setFlag(1,19,1);



	n_z.setFlag(2,0,1);
	n_z.setFlag(2,1,1);
	n_z.setFlag(2,2,1);
	n_z.setFlag(2,3,1);
	n_z.setFlag(2,4,1);
	n_z.setFlag(2,5,1);
	n_z.setFlag(2,6,1);
	n_z.setFlag(2,7,1);
	n_z.setFlag(2,8,1);
	n_z.setFlag(2,9,1);
	n_z.setFlag(2,10,1);
	n_z.setFlag(2,11,1);
	n_z.setFlag(2,12,1);
	n_z.setFlag(2,13,1);
	n_z.setFlag(2,14,1);
	n_z.setFlag(2,15,1);
	n_z.setFlag(2,16,1);
	n_z.setFlag(2,17,1);
	n_z.setFlag(2,18,1);
	n_z.setFlag(2,19,1);


	n_z.setFlag(3,0,1);
	n_z.setFlag(3,1,1);
	n_z.setFlag(3,2,1);
	n_z.setFlag(3,3,1);
	n_z.setFlag(3,4,1);
	n_z.setFlag(3,5,1);
	n_z.setFlag(3,6,1);
	n_z.setFlag(3,7,1);
	n_z.setFlag(3,8,1);
	n_z.setFlag(3,9,1);
	n_z.setFlag(3,10,1);
	n_z.setFlag(3,11,1);
	n_z.setFlag(3,12,1);
	n_z.setFlag(3,13,1);
	n_z.setFlag(3,14,1);
	n_z.setFlag(3,15,1);
	n_z.setFlag(3,16,1);
	n_z.setFlag(3,17,1);
	n_z.setFlag(3,18,1);
	n_z.setFlag(3,19,1);


	n_z.setFlag(4,0,1);
	n_z.setFlag(4,1,1);
	n_z.setFlag(4,2,1);
	n_z.setFlag(4,3,1);
	n_z.setFlag(4,4,1);
	n_z.setFlag(4,5,1);
	n_z.setFlag(4,6,1);
	n_z.setFlag(4,7,1);
	n_z.setFlag(4,8,1);
	n_z.setFlag(4,9,1);
	n_z.setFlag(4,10,1);
	n_z.setFlag(4,11,1);
	n_z.setFlag(4,12,1);
	n_z.setFlag(4,13,1);
	n_z.setFlag(4,14,1);
	n_z.setFlag(4,15,1);
	n_z.setFlag(4,16,1);
	n_z.setFlag(4,17,1);
	n_z.setFlag(4,18,1);
	n_z.setFlag(4,19,1);







	// For weight
	double a[] = {1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 
		1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
		1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
		1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
		1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};



	// For tree
	long c[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};


	// For data
	double b[] = {5.10185922142381,4.8841940331826,5.02049769972125,
		5.0274986272564,4.83391675225195,5.00320621920878,
		5.03232158562726,4.87510405978804,4.7382505508661,
		5.07636396128019,4.92423213157559,5.12373907779852,
		4.85896900852602,5.09976763652511,5.1842204158432,
		5.04509708735135,5.00006977707178,5.09830956942137,
		4.99767797745053,5.05203359019239,5.12593315325864,
		5.01325401646491,4.78601822462439,5.02918147117065,
		5.00291017741305,4.93696054139489,4.83760287702608,
		5.0022217898715,5.15245145928027,5.0479440280222,
		4.93667179323919,5.04130738825096,5.03467991965088,
		5.01560512225902,4.94893130617322,4.92676641631295,
		4.9315880021746,5.09360369786236,4.87593324700585,
		5.03599736286685,4.98104662400517,4.85976944923214,
		4.9966261201442,5.09001366193069,4.8662047154215,
		5.02041238511658,5.06382366350147,5.01407173246849,
		4.92009106116704,5.07661105249613,4.87663119465151,
		5.1292006077935,4.97637346156485,5.1882455963251,
		4.99034514155368,4.95564526288435,4.97325154875489,
		4.87663089413094,4.87874408355168,4.94226266284865,
		0.0313881585705793,0.149100283930876,-0.0873456050987942,
		0.122862407337949,0.125928866015205,-0.147495830150989,
		-0.0313859202226473,-0.0252142651797684,-0.204760239952663,
		-0.154090636850419,0.125105857305365,-0.169213972809915,
		0.0273063166306875,0.0610749722312525,-0.0335841156284721,
		0.0409721714041794,-0.111344365101984,0.130650844791011,
		-0.0765424044404146,0.00731376669552698,-0.111622184862006,
		-0.158213478981196,-0.0443037152706343,0.0047349416619317,
		0.0128522441353407,0.0395476945611412,-0.0888591372468678,
		0.173330457223522,0.000755865498641379,-0.109159744225833,
		4.85842189833249,5.22376144142292,5.02574710824793,
		4.98783940387894,4.83417602356783,4.94436055454105,
		4.97050253469801,5.05646831559322,4.95583737164363,
		5.14271491989809,5.124864880686,4.95946856836691,
		5.02084601336962,4.96214967776714,4.99837248224822,
		4.93072902749793,5.10775885275151,5.07554479532774,
		4.87075242581369,4.7474480849846,4.79797119862985,
		5.04612923878576,5.08216204647265,5.25501374037389,
		4.89780752089402,5.14582505179539,5.03909090609007,
		4.99842537393862,5.04001984938809,4.95142091748934,
		-0.044810064384099,-0.0976519394825762,-0.105634663802833,
		0.0704086110536118,-0.0423216435195832,0.0183306738550083,
		-0.0401525464748832,0.0923200556400114,0.205033424820954,
		0.0117551347947581,0.103044888782622,-0.029541856260898,
		0.0950212516776086,-0.0149091855603666,-0.0815249338415671,
		-0.27899181157196,-0.0147124360460328,0.0203896223150352,
		0.103039767464234,0.107210317550427,-0.027497590385343,
		-0.0776606539648789,-0.0602584888835754,-0.0310752371076455,
		-0.0636253462944672,-0.1241944440126,-0.0741077953265256,
		-0.0468876670369404,-0.239196635221924,-0.128910727030414,
		5.13563144967444,4.7774810898847,5.0125404473674,
		5.09242198122607,5.06973046978671,4.83028438876845,
		4.90107312484825,5.04843595550973,5.08505803814564,
		5.11175188696589,5.00312649523091,5.05336182664368,
		5.03937925708076,4.98395796485386,5.08061216180543,
		4.86640547583054,4.76595366191998,4.94825002447343,
		4.84840512560226,5.01767969102827,4.91612590343116,
		5.08068078491069,4.89830393297828,4.97029426835383,
		4.69247516013797,4.87535056789705,5.01941851987586,
		5.08102733740181,4.8387966383577,5.03649996056347,
		-0.0471069822955758,0.00071206369099642,-0.0146019629888272,
		-0.0305840705475096,-0.0871562247581997,0.0295196495663258,
		0.0591575928258538,-0.0134513717349751,0.0680581257455505,
		0.19213865848622,-0.131663860206791,0.125001835927648,
		0.0737702388143799,-0.028069365143892,0.0132612230003224,
		-0.0454610071949466,0.0400570693384921,-0.107650093783327,
		-0.115324376632818,0.0506020928034803,0.0510130180051042,
		0.0304064529596955,-0.0754381205653629,0.124769626798545,
		0.0634400657443725,-0.127843478188845,0.0757197625339355,
		0.0454719184781639,-0.0766984783842158,-0.139397394671889,
		5.13985903111553,5.09595209441767,4.89755306652601,
		5.07130503241381,5.06058311875152,5.03952391525795,
		5.10555627136212,5.21200939469293,4.94862660559836,
		5.09300742637912,5.01627182675719,5.20766887671963,
		4.91700828946856,5.10074507419489,4.97865173366616,
		4.91599480055201,4.98888943050692,5.07271387871035,
		5.02054431252543,5.12543111818263,5.02963991693922,
		4.9006557484973,4.92379720767526,5.1162210736293,
		4.91363947929215,4.87329480476473,5.06672564947552,
		4.91069332884742,4.87492022930619,4.90052914490345,
		-0.0772275433901965,0.0581805688992728,0.0468333734380458,
		0.157629401573429,-0.000655368294790761,-0.00811261795858147,
		-0.00775977457589354,-0.0926951591980736,0.0988020306518227,
		0.0733922626013021,0.021370164649839,-0.0458290125353251,
		0.0447200249014084,-0.232164118367641,0.0823333647985102,
		-0.114899479381256,0.029887758390601,-0.0589453882113132,
		0.0556660182762123,-0.10288244910334,-0.136089698667494,
		0.0917060487056026,-0.0218267469758059,0.0620178702683435,
		-0.0738069071336754,-0.0457824833859727,0.0015291205673177,
		0.0482329697596046,0.0117237998256624,-0.0728690173806403};


	//matrix n_weight(n_time,20,a);
	//matrixl n_tree(n_time, 20, c);
	//matrixl n_clusterhome(1,20);
	matrix n_Data(n_num,n_gene,b);

	//n_clusterhome(0,0) = 1;
	//n_clusterhome(0,1) = 1;
	//n_clusterhome(0,2) = 2;
	//n_clusterhome(0,3) = 3;
	//n_clusterhome(0,4) = 4;
	//n_clusterhome(0,5) = 5;

	cout << "Initializing ... " << flush;
	ClusterTree::setNumOfTimePoints(n_time);

	cout << "parameters ... " << flush;
	initializeParameters(n_Data);
	cout << "environment ... " << flush;
	MCMCEnv mainenv = MCMCEnv::initMCMCEnv(n_time, n_gene, n_num, n_Nt, n_tao, n_z, n_Data);
	cout << "agent ... " << flush;
	mcmc n_mcmc(mainenv);

	cout << "done." << endl;

	double probability = 1.0;

	cout<<"old parameters"<<endl;
	n_mcmc.env.writeStatus(cout);

	ofstream outfile( "outfile_kmeans.txt" );
	if ( ! outfile ) {
		cerr << "error: unable to open output file!\n";

	}

	ofstream outfile_tree("tree_kmeans.txt");
	if ( ! outfile_tree ) {
		cerr << "error: unable to open output file!\n";
	}

	bool move = false;

	for(j=0; j<500000; j++){

		n_mcmc.env.sampleTao();;


		cout<<"STEP: "<<j+1<<endl;

		outfile<<"STEP: "<<j+1<<std::endl;

		n_mcmc.env.writeStatus(outfile);

		//cout<<"After SplitMerge_move!"<<std::endl;
		outfile<<"After SplitMerge_move!"<<std::endl;
		probability = 0.0;
		move = n_mcmc.SplitMerge_move(probability);

		outfile<<"move: "<<move<<std::endl;

		if(move){
			outfile<<"SplitSplitSplit:"<<endl;
			outfile<<"accepted probability:"<<endl;
		}else{
			outfile<<"MergeMergeMerge:"<<endl;
			outfile<<"accetped probability:"<<endl;
		}

		outfile<<probability<<endl;
		n_mcmc.env.writeStatus(outfile);

		//cout<<"After BirthDeath_move!"<<std::endl;
		outfile<<"After BirthDeath_move!"<<std::endl;

		probability = 0.0;
		move = n_mcmc.BirthDeath_move(probability);

		if(move){
			outfile<<"BirthBirthBirth:"<<std::endl;
			outfile<<"accepted probability:"<<endl;
		}else{
			outfile<<"DeathDeathDeath:"<<std::endl;
			outfile<<"accepted probability:"<<endl;
		}

		outfile<<probability<<endl;
		n_mcmc.env.writeStatus(outfile);

		outfile_tree<<n_mcmc.env.treeSummary()<<endl;

	}

	return 0;
}




