#include "MCMCEnv.h"
#include "Random.h"
#include <stdexcept>
#include <deque>
#include <iomanip>
#include <cmath>
#include <sstream>

#define SMALLNUM 1e-200
#define TREE_ID_SIZE	4

unsigned long MCMCEnv::NumOfTP = 0;
unsigned long MCMCEnv::NumOfGenes = 0;
unsigned long MCMCEnv::NumOfData = 0;
ClusterTree::NumOfSampleContainer MCMCEnv::DataNumEachTP;	// number of data in each time point

matrix MCMCEnv::mu1;
matrix MCMCEnv::mu0;
matrix MCMCEnv::sigma0;
matrix MCMCEnv::sigma1;
double MCMCEnv::beta0;
double MCMCEnv::beta1;
double MCMCEnv::deltar;
double MCMCEnv::alpha;
double MCMCEnv::shape;
double MCMCEnv::bk; // For split_merge move and birth_death move, we give equal probability.
double MCMCEnv::ranc; // Tail birth is given much more porbability.
double MCMCEnv::k1;
double MCMCEnv::k0;

MCMCEnv::SortedULContainer MCMCEnv::TPStartIndex,
	MCMCEnv::ReverseTPStartIndex;	// the starting index for each time point

using namespace std;

// matrix calculation
// In this function, cluster inicator z is assumbed to be reflaged using 'reflag' function.
// tao_NULL = 1, delete tao=0, otherwise delete tao=1.
matrix MCMCEnv::reData(long ID, bool tao_NULL, const TaoSet &newTao) const {
	matrix one(Data);
	std::vector<std::vector<long> > mclust = Flags.onezerocluster(ID);
	long i,j,k;
	long length = 0;
	for(i=0; i<mclust.size(); i++){
		for(j=0; j<mclust.at(i).size(); j++) {
			for(k=0; k<one.cols(); k++) {
				one.setValue(length + j, k, Data.getValue(length + j, k) 
					* ((tao_NULL == newTao[k])? (newTao[k]? mclust.at(i).at(j): 1): 0));
			}
		}

		length += j;
	}

	return one;

}

matrix MCMCEnv::datacov(long flag, bool tao_NULL, const TaoSet &newTao) const {
	matrix one = reData(flag, tao_NULL, newTao);
	//matrix two = (tao_NULL? mu1: mu0);
	
	matrix two(1, NumOfGenes);
	for(unsigned long k = 0; k < NumOfGenes; k++){
		two(0, k) = ((newTao[k] == tao_NULL)? mu1(0, k): 0.0);
	}

	long x = (tao_NULL? Flags.flagnum(flag): NumOfData);

	matrix mid;
	matrix one_mean = (one.datasum() * (1.0 / (double) x));
	TimeCoordinate xx;

	matrix cov_NULL(Data.cols(), Data.cols());
	int i,j;

	for(i = 0; i < Data.rows(); i++)
	{
		xx = IndexToCoor(i);
		if((Flags.getFlag(xx.first, xx.second) == flag) || !tao_NULL){
			mid = (one.getRow(i) - one_mean);
		} else {
			mid = one.getRow(i);
		}

		//std::cout<<"Matrix transpose: "<<std::endl;
		//std::cout<<mid<<std::endl;
		cov_NULL += (mid.transpose() * mid);
	}

	mid = two - one_mean;
	/*std::cout<<"mu0: "<<std::endl;
	std::cout<<two<<std::endl;
	std::cout<<"mean: "<<std::endl;
	std::cout<<one_mean<<std::endl;*/
	two = (mid.transpose() * mid);
	return cov_NULL.rbind(two);

}

// Caution: if the index is out of bound, will return NumOfTimePoints
MCMCEnv::TimeCoordinate MCMCEnv::IndexToCoor(unsigned long index) const {
	SortedULContainer::const_iterator itor = TPStartIndex.upper_bound(index);
	itor--;
	return TimeCoordinate(itor->second, index - itor->first);
}

unsigned long MCMCEnv::CoorToIndex(const TimeCoordinate &corr) const {
	return ReverseTPStartIndex[corr.first] + corr.second;
}


MCMCEnv::MCMCEnv(const TaoSet &tao, const ClusterFlags &flags, const matrix &data)
	: ID_max(1), root_ID(0), Flags(flags), Tao(tao), UpToDate(false), Data(data)
{
	// actually head node need to be initialized here
	ClusterTree &ctree = createTree();
	cout << "Tree" << flush;
	ctree.fillWeights(1.0);
	cout << "Tree" << flush;
	ctree.samples = DataNumEachTP;
	
}

MCMCEnv MCMCEnv::initMCMCEnv(unsigned long numOfTimePoints, unsigned long numOfGenes,
	unsigned long numOfData, const std::vector<unsigned long> &numOfDataInEachTimePoint,
	const TaoSet &tao, const ClusterFlags &flags, const matrix &p_data) {
		NumOfTP = numOfTimePoints;
		NumOfGenes = numOfGenes;
		NumOfData = numOfData;
		DataNumEachTP.resize(NumOfTP);
		DataNumEachTP.assign(numOfDataInEachTimePoint.begin(), numOfDataInEachTimePoint.end());

		unsigned long index = 0, time = 0;
		TPStartIndex.clear();
		ReverseTPStartIndex.clear();

		for(ClusterTree::NumOfSampleContainer::const_iterator itor = DataNumEachTP.begin();
			itor != DataNumEachTP.end(); itor++) {
				TPStartIndex.insert(SortedULContainer::value_type(index, time));
				ReverseTPStartIndex.insert(SortedULContainer::value_type(time, index));
				index += *itor;
				time++;
		}
		TPStartIndex.insert(SortedULContainer::value_type(index, time));

		cout << NumOfTP << flush;
		return MCMCEnv(tao, flags, p_data);
}

MCMCEnv::MCMCEnv(const MCMCEnv &oldenv): MapClusterTrees(oldenv.MapClusterTrees),
	ID_max(oldenv.ID_max), root_ID(oldenv.root_ID), Flags(oldenv.Flags), Tao(oldenv.Tao),
	UpToDate(oldenv.UpToDate), LogDensityValue(oldenv.LogDensityValue), Data(oldenv.Data) {
		// NOTICE: I'm not exactly sure if shallow copy of MapClusterTrees works, 
		//         so need verifying
}

MCMCEnv &MCMCEnv::operator=(const MCMCEnv &oldenv) {
	MapClusterTrees = oldenv.MapClusterTrees;
	ID_max = oldenv.ID_max;
	root_ID = oldenv.root_ID;
	Flags = oldenv.Flags;
	Tao = oldenv.Tao;
	UpToDate = oldenv.UpToDate;
	LogDensityValue = oldenv.LogDensityValue;
	// doesn't need to change data
}

MCMCEnv::~MCMCEnv(void)
{
	//// when environment is destoryed, destory all the trees
	//for(TreeContainer::const_iterator itor = MapClusterTrees.begin();
	//	itor != MapClusterTrees.end(); itor++) {
	//		if(itor->second) {
	//			delete itor->second;
	//			//itor->second = NULL;
	//		}
	//}
}

unsigned long MCMCEnv::getDataNum() {
	return NumOfData;
}

void MCMCEnv::initializeParameters(const matrix &p_mu1, const matrix &p_mu0, const matrix &p_sigma1,
	const matrix &p_sigma0, double p_beta1, double p_beta0, double p_deltar, double p_alpha,
	double p_shape, double p_bk, double p_ranc) {
		mu1 = p_mu1;
		mu0 = p_mu0;
		sigma1 = p_sigma1;
		sigma0 = p_sigma0;
		beta1 = p_beta1;
		beta0 = p_beta0;
		deltar = p_deltar;
		alpha = p_alpha;
		shape = p_shape;
		bk = p_bk;
		ranc = p_ranc;
}


ClusterTree &MCMCEnv::getTreeFromID(unsigned long long ID) {
	if(MapClusterTrees.find(ID) == MapClusterTrees.end()) {
		ostringstream ostr;
		ostr << "ID " << ID << " not in the list!";
		throw(std::logic_error(ostr.str()));
	}
	return MapClusterTrees.find(ID)->second;
}

const ClusterTree &MCMCEnv::getTreeFromID(unsigned long long ID) const {
	if(MapClusterTrees.find(ID) == MapClusterTrees.end()) {
		ostringstream ostr;
		ostr << "ID " << ID << " not in the list!";
		throw(std::logic_error(ostr.str()));
	}
	return MapClusterTrees.find(ID)->second;
}

ClusterTree &MCMCEnv::createTree(unsigned long long parentID, unsigned long time) {
	unsigned long long newID = ID_max++;
	ClusterTree &parent = getTreeFromID(parentID);
	//if(parent.getChildID(time)) {
	//	// there is child here, so throw error
	//	throw(std::logic_error("Already have a child at the time!"));
	//}
	parent.setChild(newID, time);
	MapClusterTrees.insert(TreeContainer::value_type(newID, ClusterTree(parent, newID, time)));
	UpToDate = false;
	return getTreeFromID(newID);
}

ClusterTree &MCMCEnv::createTree() {
	// creating mother
	if(root_ID) {
		throw(std::logic_error("Mother node already created!"));
	}
	root_ID = ID_max++;
	MapClusterTrees.insert(TreeContainer::value_type(root_ID, ClusterTree(root_ID)));
	UpToDate = false;
	return getTreeFromID(root_ID);
}

void MCMCEnv::removeTree(unsigned long long TreeID) {
	if(getTreeFromID(TreeID).getSampleNum()) {
		throw(std::logic_error("Tree has data points, cannot be removed."));
	}
	MapClusterTrees.erase(TreeID);
	UpToDate = false;
}

ClusterTree &MCMCEnv::getTreeHead() {
	return MapClusterTrees.find(root_ID)->second;
}

const ClusterTree &MCMCEnv::getTreeHead() const {
	return MapClusterTrees.find(root_ID)->second;
}

MCMCEnv::TreeSet MCMCEnv::getSplitSet() const {

	MCMCEnv::TreeSet result;
	result.reserve(NumOfTP * 2);
	
	//cout << "Generating Split Set ... " << endl;
	for(TreeContainer::const_iterator itor = MapClusterTrees.begin();
		itor != MapClusterTrees.end(); itor++) {
			//cout << "ID: " << itor->second.ID << " Parent ID: " 
			//	<< itor->second.parentID 
			//	<< " Born time: " << itor->second.born_time << endl;
			for(unsigned long t = itor->second.born_time + 1; t < NumOfTP; t++) {
				// the born time of its child must be at least 1 more than this
				//cout << "Samples(" << t << "): " << itor->second.samples[t] << endl;
				if(itor->second.samples[t] && !itor->second.children[t]) {
					// has sample and no child at time t
					result.push_back(MCMCEnv::TreeSet::value_type(t, itor->first));
				}
			}
	}
	return result;
	//long i,j;
	//lvector splitone;
	////Collect nonempty cluster vector.
	//std::vector<long> flags = newz.getTtoTindicator(n_timepoints);

	//long midf,midt,mids,sr = 0;
	//long fl = flags.size();
	//for(i=0; i<fl; i++){
	//	midf = flags.at(i);
	//	midt = newz.getEarliestTime(midf);
	//	

	//	for(j=1; j<n_timepoints; j++){ 

	//		mids = (j==midt-1)?(newchome(0,midf-1)-1):(midf-1);

	//		if((newtree(j-1,mids)==0)&&(newz.flaginT(midf,j+1))){
	//		   splitone.push_back(j+1);
	//		   splitone.push_back(midf);
	//		   sr++;
	//		}
	//	}
	//	
	//}


	//return matrixl(sr,2,splitone);

}

MCMCEnv::TreeMergeSet MCMCEnv::getMergeSet() const {
	//std::vector<long> flags = newz.getTtoTindicator(n_timepoints);
	//std::vector<long> freeflags;
	//std::vector<long> nonfreeflags;
	//lvector mergeone;
	//long i,j,k,s=0;
	//long time1, time2, time0;
	//long sr=0;
	//long n,m,l;

	unsigned long long childID, parentID;

	TreeMergeSet result;
	result.reserve(NumOfTP * 2);

	for(TreeContainer::const_iterator itor = MapClusterTrees.begin();
		itor != MapClusterTrees.end(); itor++) {
			// first check if the tree doesn't have any children
			if(!itor->second.getNumOfChildren()) {
				// this tree does not have any children
				childID = itor->second.ID;
				for(TreeContainer::const_iterator itor_parent = MapClusterTrees.begin();
					itor_parent != MapClusterTrees.end(); itor_parent++) {
						if(itor_parent->second.ID != itor->second.ID 
							&& itor_parent->second.born_time < itor->second.born_time) {
								// this parent is OK
								result.push_back(TreeMergeSet::value_type(itor_parent->second.ID,
									itor->second.ID));
						}
				}
			}
	}

	return result;
	//n = flags.size();
	//if(n != 1){
	//	for(i=0; i<n; i++){
	//		s=0;
	//		for(j=0; j<n_timepoints; j++){
	//			if(newtree(j,flags.at(i)-1)!=0){
	//				s++;
	//				nonfreeflags.push_back(flags.at(i));
	//				break;
	//			}
	//		}
	//		if(s==0){
	//			freeflags.push_back(flags.at(i));
	//		}

	//	}
	//	m = freeflags.size();
	//	l = n-m;


	//	for(i=0; i<m; i++){
	//		time1 = newweight.getEarliestTime(freeflags.at(i));
	//		for(k=i+1; k<m; k++){
	//			time0 = newz.getEarliestTime(freeflags.at(k));
	//			if(time1<=time0){
	//				mergeone.push_back(time0);
	//				mergeone.push_back(freeflags.at(i));
	//				mergeone.push_back(freeflags.at(k));
	//				sr++;
	//			}else{
	//				mergeone.push_back(time1);
	//				mergeone.push_back(freeflags.at(k));
	//				mergeone.push_back(freeflags.at(i));
	//				sr++;
	//			}
	//		}


	//		for(j=0; j<l; j++){
	//			time2 = newweight.getEarliestTime(nonfreeflags.at(j));
	//			if(time2<=time1){
	//				mergeone.push_back(time1);
	//				mergeone.push_back(nonfreeflags.at(j));
	//				mergeone.push_back(freeflags.at(i));
	//				sr++;
	//			}

	//		}
	//	}
	//}
	//return matrixl(sr,3,mergeone);
}

MCMCEnv::TreeMergeSet MCMCEnv::getDeathSet() const {
	TreeMergeSet result;
	result.reserve(NumOfTP * 2);
	
	unsigned long long childID, parentID;

	for(TreeContainer::const_iterator itor = MapClusterTrees.begin();
		itor != MapClusterTrees.end(); itor++) {
			// first check if the tree doesn't have any children
			if(!itor->second.getNumOfChildren()) {
				// this tree does not have any children
				if(!itor->second.getSampleNum()) {
					// this tree is empty
					childID = itor->second.ID;
					for(TreeContainer::const_iterator itor_parent = MapClusterTrees.begin();
						itor_parent != MapClusterTrees.end(); itor_parent++) {
							if(itor_parent->second.ID != itor->second.ID 
								&& itor_parent->second.born_time < itor->second.born_time) {
									// this parent is OK
									result.push_back(TreeMergeSet::value_type(itor_parent->second.ID,
										itor->second.ID));
							}
					}
				}
			}
	}

	return result;
}

void MCMCEnv::flagSplit(double &P_alloc, bool &NULLset, double &f_ui,  
	const MCMCEnv::TreeSet::value_type &split_pair) {
		ClusterTree &parent = getTreeFromID(split_pair.second);
		double ut;
		f_ui = 1.0;
		long s = 0;
		if((split_pair.first) && (split_pair.first < NumOfTP) && 
			(parent.samples[split_pair.first])) {
				// first create a new tree if the split_pair
				ClusterTree &child = createTree(split_pair.second, split_pair.first);

				for(unsigned long i = split_pair.first; i < NumOfTP; i++) {

					/*weight*/
					ut = ran_beta(2.0,2.0);
					double old_weight = parent.weights[i];
					f_ui *= (old_weight > SMALLNUM)? betad(ut, 2.0, 2.0): 1.0;
					/* This is a good choice for resetting the cluster indicators and weight parameter */
					parent.weights[i] = ut * old_weight;
					child.weights[i] = (1 - ut) * old_weight;

					// flags
					if(parent.samples[i]) {
						// there are samples in this time point for the parent
						for(long k = 0; k < Flags.cols(i); k++){
							if(Flags(i,k) == parent.ID) {
								Flags(i,k) = ran_nber(parent.ID, child.ID, ut);
								if(Flags(i,k) == parent.ID){
									//one(i-1,k) = one(i-1,k);
									P_alloc *= ut;
									// nothing is changed in terms of sample number
								}else{
									P_alloc *= (1-ut);
									(parent.samples[i])--;
									(child.samples[i])++;
									s++;
								}			
							}

							// cluster indicator reloaded.
						}
					}
				}

				NULLset = (s == 0);
				/*std::cout<<"new"<<std::endl;
				std::cout<<one<<std::endl;
				std::cout<<two<<std::endl;
				std::cout<<newtree<<std::endl;
				std::cout<<newchome<<std::endl;
				std::cout<<P_alloc<<std::endl;
				std::cout<<NULLset<<std::endl;*/
				UpToDate = false;

		} else {
			std::cout<<"This is an empty cluster!"<<std::endl;
			std::cout<<"This cluster can not be splitted!"<<std::endl;
		}
}

void MCMCEnv::flagMerge(double &P_alloc, double &f_ui, const TreeMergeSet::value_type &merge_pair) {

	unsigned long parentNum, childNum;
	double ut;

	P_alloc = 1.0;
	f_ui = 1.0;
	if(merge_pair.second != root_ID){

		ClusterTree &parent = getTreeFromID(merge_pair.first),
			&child = getTreeFromID(merge_pair.second);

		unsigned long time = child.born_time;

		for(unsigned long t = time; t < NumOfTP; t++){
			
			if(child.weights[t] > SMALLNUM && parent.weights[t] > SMALLNUM) {
				ut = parent.weights[t] / (parent.weights[t] + child.weights[t]);
				parentNum = Flags.tflagnum(parent.ID, t);
				childNum = Flags.tflagnum(child.ID, t);
				P_alloc *= pow(ut, (int) parentNum) * pow(1 - ut, (int) childNum);
				f_ui *= betad(ut,2.0,2.0);
				parent.weights[t] += child.weights[t];
				// calc P_alloc and change weights and sample count
			}

			for(unsigned long k = 0; k < Flags.cols(t); k++){
				if(Flags(t, k) == child.ID) {
					Flags(t, k) = parent.ID;
				}
				// change cluster indicator
			}
			parent.samples[t] += child.samples[t];
			child.samples[t] = 0;
		}
		getTreeFromID(child.parentID).removeChild(child.born_time);
		// remove child from its original parent
		child.parentID = 0;			// reset the parentID of the child, mark it for deletion
		removeTree(child.ID);
		UpToDate = false;

	} else{
		std::cout<<"These two clusters can not be merged!"<<std::endl;
		std::cout<<"Maybe empty cluster or maybe the time is not one of its starting time point!"<<std::endl;
	}
}

void MCMCEnv::flagBirth(const TreeSet::value_type &splitPair) {
	double weightratio, jacobi, f_wstar;
	return flagBirth(splitPair, weightratio, jacobi, f_wstar);
}

void MCMCEnv::flagBirth(const TreeSet::value_type &splitPair,
	double &weightratio, double &jacobi, double &f_wstar) {
		long j,k,n,timec;
		double w_star;

		jacobi = 1.0;
		f_wstar = 1.0;
		weightratio = 1.0;
		unsigned long time = splitPair.first;

		const ClusterTree &parent = getTreeFromID(splitPair.second);

		if((time < NumOfTP) && parent.getSampleNum(time)){
			/*Justify whether clusterindex is an empty cluster.*/

			ClusterTree &child = createTree(parent.ID, time);

			for(unsigned long t = time; t < NumOfTP; t++){
				/*weight*/
				timec = getNoZeroWeights(t);
				w_star = ran_beta(1.0, (double) timec);
				jacobi *= pow(1 - w_star, timec - 1);
				f_wstar *= betad(w_star, 1.0, (double) timec);
				weightratio *= (pow(w_star, alpha - 1) * pow(1 - w_star, 
					(double)timec * (alpha - 1)) / betaf(alpha, (double) timec * alpha));

				/* This is a good choice for resetting the cluster indicators and weight parameter */
				//two(i-1,clusterindex-1) = (1.0 - w_star) * weight(i-1,clusterindex-1);
				child.weights[time] = w_star;

				for(TreeContainer::iterator itor = MapClusterTrees.begin();
					itor != MapClusterTrees.end(); itor++) {
						if(itor->first != child.ID){
							itor->second.weights[t] = (1.0 - w_star) * itor->second.weights[t];
						}
				}
				/*weight relocated.*/
			}


			// Tree reset
			// This step is implemented according to the weight setting.

			/*std::cout<<"Birth"<<std::endl;
			std::cout<<"weightratio"<<std::endl;
			std::cout<<weightratio<<std::endl;
			std::cout<<"Jacobi"<<std::endl;
			std::cout<<jacobi<<std::endl;
			std::cout<<"f_wstar"<<std::endl;
			std::cout<<f_wstar<<std::endl;*/
			UpToDate = false;

		}else{
			std::cout<<"This is an empty cluster!"<<std::endl;
			std::cout<<"This cluster can not be splitted!"<<std::endl;
		}

}

void MCMCEnv::flagDeath(const TreeMergeSet::value_type &merge_pair, 
	double &jacobi, double &weightratio, double &f_wstar) {

		long mergeflag, leftflag;
		long mergenum, leftnum;
		long i,j,k;
		double midw,midn;

		jacobi = 1.0;
		weightratio = 1.0;
		f_wstar = 1.0;

		if(merge_pair.second != root_ID){

			ClusterTree &parent = getTreeFromID(merge_pair.first),
				&child = getTreeFromID(merge_pair.second);

			unsigned long time = child.born_time;
			//// Mother
			//leftflag = clusterindex1;
			//// Son
			//mergeflag = clusterindex2;
			for(unsigned long t = time; t < NumOfTP; t++){
				midw = child.weights[t];
				if(midw > SMALLNUM){
					midn = getNoZeroWeights(t);
					f_wstar *= betad(midw, 1.0, (double) midn);
					weightratio *= (betaf(alpha, (double) (midn - 1) * alpha)
						/ pow(midw, (alpha - 1.0)) 
						/ pow(1.0 - midw, (double) (midn - 1) * (alpha - 1.0)));
					jacobi *= pow(1.0 - midw, -1.0 * (double) (midn - 2));

					for(TreeContainer::iterator itor = MapClusterTrees.begin();
						itor != MapClusterTrees.end(); itor++) {
							if(itor->first != child.ID){
								itor->second.weights[t] = itor->second.weights[t] / (1.0 - midw);
							}
					}
				}
				// cluster indicator reloaded.
			}

			getTreeFromID(child.parentID).removeChild(child.born_time);
			// remove child from its original parent
			child.parentID = 0;			// reset the parentID of the child, mark it for deletion
			removeTree(child.ID);
			UpToDate = false;

			/*std::cout<<"Death"<<std::endl;
			std::cout<<"weightratio"<<std::endl;
			std::cout<<weightratio<<std::endl;
			std::cout<<"Jacobi"<<std::endl;
			std::cout<<jacobi<<std::endl;
			std::cout<<"f_wstar"<<std::endl;
			std::cout<<f_wstar<<std::endl;*/

		} else{
			std::cout<<"These two clusters can not be merged!"<<std::endl;
			std::cout<<"Maybe empty cluster or maybe the time is not one of its starting time point!"<<std::endl;
		}

}


double MCMCEnv::calcLogDensity() const {
	if(!UpToDate) {
		LogDensityValue = calcLogDensity(Tao);
		UpToDate = true;
	} 
	return LogDensityValue;

}

double MCMCEnv::calcLogDensity(const TaoSet &newTao) const {

	double den = 0.0;
	//long flag;
	long i,j;
	//long clusternum = Flags.getMaxFlag();
	long cclusternum;		// number of samples in the cluster
	double gammaprod = 0.0;
	double K0=1.0, K1=1.0;
	long dim = NumOfGenes;
	matrix S0, S1, mid;

	double sigmaConst0 = sigma0(0, 0), sigmaConst1 = sigma1(0, 0);

	long taonum=0;
	for(i=0; i<dim; i++) {
		taonum += (newTao.at(i))? 1: 0;
	}
	for(unsigned long k = 0; k < NumOfGenes; k++){
		sigma1(k, k) = (newTao[k]? sigmaConst1: 1.0);
		sigma0(k, k) = (!newTao[k]? sigmaConst0: 1.0);
	}
	/*std::cout<<"taonum"<<std::endl;
	std::cout<<taonum<<std::endl;*/
	if((taonum > 0) && (taonum < NumOfGenes)){
		for(j=1; j<=(NumOfGenes - taonum); j++) {
			gammaprod *= log(gammaf(0.5 * (NumOfData + deltar + NumOfGenes - taonum - j)))
				- log(gammaf(0.5 * (deltar + NumOfGenes - taonum - j)));
		}

		K0 = log(beta0 * NumOfData + 1) * (-0.5 * (NumOfData - taonum)) + gammaprod;
		/*std::cout<<"K0"<<std::endl;
		std::cout<<K0<<std::endl;*/
		gammaprod = 1.0;

		mid = datacov(root_ID, 0, newTao);
		/* std::cout<<"mid"<<std::endl;
		std::cout<<mid<<std::endl;*/
		S0 = mid.getBlock(1,dim,1,dim)
			+ mid.getBlock(dim+1,2*dim,1,dim)*(NumOfData/(beta0*NumOfData+1));
		/* std::cout<<"S0:"<<std::endl;
		std::cout<<S0<<std::endl;*/
		den = K0 + log(fabs(sigma0.determinant())) * (0.5*(deltar+NumOfGenes-taonum-1))
			+ log(fabs((sigma0+S0).determinant())) * (-0.5*(NumOfData+deltar+NumOfGenes-taonum-1));

		//for(flag=1; flag<=clusternum; flag++){
		for(TreeContainer::const_iterator itor = MapClusterTrees.begin();
			itor != MapClusterTrees.end(); itor++) {
				cclusternum = itor->second.getSampleNum();
				if(cclusternum){
					for(j=1; j<=taonum; j++) {
						gammaprod += log(gammaf(0.5 * (cclusternum + deltar + taonum - j)))
							- log(gammaf(0.5 * (deltar + taonum - j)));
					}

					K1 = log(itor->second.calcKcWeight()) 
						+ log(beta1 * cclusternum + 1) * (-(double) taonum / 2.0) + gammaprod;
					//std::cout<<"K1"<<std::endl;
					//std::cout<<K1<<std::endl;
					gammaprod = 0.0;

					mid = datacov(itor->first, 1, newTao);
					//std::cout<<"S1mid:"<<std::endl;
					//std::cout<<mid<<std::endl;
					S1 = mid.getBlock(1, dim, 1, dim) 
						+ mid.getBlock(dim + 1, 2 * dim, 1, dim) * (cclusternum / (beta1 * cclusternum + 1));
					/* std::cout<<"S1:"<<std::endl;
					std::cout<<S1<<std::endl;*/

					den += K1 + log(fabs(sigma1.determinant())) * (0.5 * (deltar+taonum-1))
						+ log(fabs((sigma1+S1).determinant())) * (-0.5*(cclusternum+deltar+taonum-1));
				}

		}
	} else if(taonum==0){
		for(j=1; j<=(NumOfGenes-taonum); j++) {
			gammaprod += log(gammaf(0.5*(NumOfData+deltar+NumOfGenes-taonum-j)))
				- log(gammaf(0.5*(deltar+NumOfGenes-taonum-j)));
		}

		K0 = log(beta0*NumOfData+1) * (-0.5*(NumOfGenes-taonum)) + gammaprod;
		/*  std::cout<<"K0"<<std::endl;
		std::cout<<K0<<std::endl;*/
		gammaprod = 0.0;

		mid = datacov(root_ID, 0, newTao);
		/*   std::cout<<"mid"<<std::endl;
		std::cout<<mid<<std::endl;*/
		S0 = mid.getBlock(1,dim,1,dim)
			+ mid.getBlock(dim+1,2*dim,1,dim)*(NumOfData/(beta0*NumOfData+1));
		/* std::cout<<"S0:"<<std::endl;
		std::cout<<S0<<std::endl;*/
		den = K0 + log(fabs(sigma0.determinant())) * (0.5*(deltar+NumOfGenes-taonum-1))
			+ log(fabs((sigma0+S0).determinant())) * (-0.5*(NumOfData+deltar+NumOfGenes-taonum-1));

	} else {

		//for(flag=1; flag<=clusternum; flag++){
		for(TreeContainer::const_iterator itor = MapClusterTrees.begin();
			itor != MapClusterTrees.end(); itor++) {
				cclusternum = itor->second.getSampleNum();
				if(cclusternum != 0){
					for(j = 1; j <= taonum; j++) {
						gammaprod += log(gammaf(0.5 * (cclusternum + deltar + taonum - j))) 
							- log(gammaf(0.5 * (deltar + taonum - j)));
					}
					/*std::cout<<"gammaprod"<<std::endl;
					std::cout<<gammaprod<<std::endl;*/
					K1 = log(itor->second.calcKcWeight()) 
						+ log(beta1 * cclusternum + 1) * (-(double) taonum / 2.0) + gammaprod;
					
					gammaprod = 0.0;

					mid = datacov(itor->first, 1, newTao);
					/*std::cout<<"S1mid:"<<std::endl;
					std::cout<<mid<<std::endl;*/
					
					S1 = mid.getBlock(1,dim,1,dim) 
						+mid.getBlock(dim+1,2*dim,1,dim)*(cclusternum/(beta1*cclusternum+1));
					/*std::cout<<"density_K1"<<std::endl;
					std::cout<<K1<<std::endl;
					std::cout<<"density_Q0"<<std::endl;
					std::cout<<pow(fabs(sigma1.determinant()),0.5*(deltar+taonum-1))<<std::endl;
					std::cout<<"density_Q0+S1"<<std::endl;
					std::cout<<pow(fabs((sigma1+S1).determinant()),-0.5*(cclusternum+deltar+taonum-1))<<std::endl;
					*/
					den += K1 + log(fabs(sigma1.determinant())) * (0.5*(deltar+taonum-1))
						+ log(fabs((sigma1+S1).determinant())) * (-0.5*(cclusternum+deltar+taonum-1));
				}

		}

	}

	for(unsigned long k = 0; k < NumOfGenes; k++){
		sigma1(k, k) = sigmaConst1;
		sigma0(k, k) = sigmaConst0;
	}

	return den;

}

long MCMCEnv::getNoZeroWeights(unsigned long time) const {
	// get the number of clusters that have non-zero weights at time
	long result = 0;
	//cout << time << "/";
	for(TreeContainer::const_iterator itor = MapClusterTrees.begin(); 
		itor != MapClusterTrees.end(); itor++) {
			//cout << itor->second.weights[time] << ' ';
			if(itor->second.weights[time] > SMALLNUM) {
				result++;
			}
	}
	//cout << "|" << result << endl;
	return result;
}


double MCMCEnv::calcPChos(const TreeMergeSet::value_type &parentChildPair, const bool NULLset,
	const TreeSet &SplitSet) const {
		const ClusterTree &parent = getTreeFromID(parentChildPair.first),
			&child = getTreeFromID(parentChildPair.second);
		unsigned long time = getTreeFromID(parentChildPair.second).born_time;
		long G_star = getClusterNumber();
		long G1_star = getNonEmptyClusterNumber();
		long G0_star = G_star - G1_star;
		long n;
		double s = 0.0;
		/*std::cout<<"Three chosen probabilities."<<std::endl;
		std::cout<<1.0/((double)(G_star*G1_star))<<std::endl;
		std::cout<<1.0/(double)G_star<<std::endl;
		std::cout<<2.0/(double)G_star<<std::endl;*/
		if(NULLset){
			return 1.0 / ((double)(G_star * G1_star));
		}else{
			n = calcSimilarity(time, parent, child, NULLset, SplitSet);

			s = ((n == 2)? (2.0 / (double) G_star): (1.0 / (double) G_star));

			return s;
			//return s/(double)time;
			//return pow(s,time-1);
			//return pow(s,time);
		}
}

// Return an integar indicating the relationship of the two splitted clusters
// 0: a cluster is empty.
// 1: The relationship is not closest.
// 2: The relationship is closest.
// NULLset tells clusterson is empty or not.
double MCMCEnv::calcSimilarity(unsigned long time, const ClusterTree &parent, const ClusterTree &child,
	const bool NULLset, const TreeSet &SplitSet) const {
		long n = SplitSet.size();
		long i, m = 2;
		double dist_ms, dist_mi;
		if(NULLset){
			return 0;
		}else{
			dist_ms = this->calcClusterDist(time, parent, time, child);
			for(TreeSet::const_iterator itor = SplitSet.begin(); itor != SplitSet.end(); itor++){
				dist_mi = this->calcClusterDist(time, parent, itor->first, getTreeFromID(itor->second));
				if(dist_ms > dist_mi){
					m = 1;
					break;
				}
			}
		}
		return m;
}

double MCMCEnv::calcClusterDist(const unsigned long time1, const ClusterTree &cluster1, 
	const long time2, const ClusterTree &cluster2) const {
		double c = 0.0;
		matrix a,b;
		long i;
		a = calcClusterMean(time1, cluster1);
		b = calcClusterMean(time2, cluster2);
		/*std::cout<<a<<std::endl;
		std::cout<<b<<std::endl;*/
		for(i = 0; i < NumOfGenes; i++){
			c += pow(a(0,i)-b(0,i),2);
		}
		return c;

}

matrix MCMCEnv::calcClusterMean(const unsigned long time, const ClusterTree &cluster) const {

	matrix gdata(1, NumOfGenes);
	long i, j, s = 0, n = 0;
	for(i = time; i < NumOfTP; i++){
		for(j = 0; j < Flags.cols(i); j++){
			if(Flags(i, j) == cluster.ID){
				gdata += Data.getRow(CoorToIndex(TimeCoordinate(i, j)));
				n++;
			}
		}
	}

	gdata *= (1/(double)n);

	return gdata;
}

// Accept probability for split move, the input cluster index must be nonempty at least in the beginning.
// newz is new cluster indicator after split move
// newweight is new weight matrix after split move
// This function follows a random sample from 'splitset' result.
double MCMCEnv::apSplit(const MCMCEnv::TreeSet::value_type &split_pair, const bool NULLset, 
	const MCMCEnv::TreeSet &splitsets, const long splitnum, const double P_alloc, const double f_ui,
	const MCMCEnv &oldenv) const {
		double densityratio, modelratio;
		double weightratio = 1.0;
		double P_chos = 1.0;
		double AP = 1.0;
		double dbratio = 1.0;
		double jacobi = 1.0;
		long i;
		if(splitnum == 0){
			return 0.0;
		}else{
			densityratio = exp(calcLogDensity() - oldenv.calcLogDensity());
			const ClusterTree &oldTree = oldenv.getTreeFromID(split_pair.second),
				&newTree = getTreeFromID(split_pair.second),
				&newChildTree = getTreeFromID(newTree.getChildID(split_pair.first));
			unsigned long time = split_pair.first;
			for(i = split_pair.first; i < NumOfTP; i++){
				// If the first cluster is an empty cluster, directly return 0.0.
				if(oldTree.weights[i] > SMALLNUM){
					weightratio *= pow(newTree.weights[i], alpha - 1) * pow(newChildTree.weights[i], alpha - 1)
						/ pow(oldTree.weights[i], alpha - 1) 
						/ betaf(alpha, ((double)oldenv.getNoZeroWeights(i))*alpha);
					jacobi *= oldTree.weights[i];
				}
			}
			// The ratio of f(Tree_new) and f(Tree_old).
			// If we set the same unchange and change probability, then it is equal to 1.0; 
			modelratio = 1.0;
			// The ratio of d_new and b_old, here dbratio = 1.0, because d_new = b_old = 0.5.
			dbratio = (1.0-bk)/bk;
			// Parameter 'splitnum': The number of cluster vector that can be used to do split move.
			//splitnum = 1.0;//
			// A function must be written to summarize the number of individuals in new and old clusters
			//P_alloc = 1.0;
			// Probabilities must be designed to describe the merge clusters.
			P_chos = calcPChos(TreeMergeSet::value_type(newTree.ID, newChildTree.ID), NULLset, splitsets);


			AP = densityratio * weightratio * modelratio * dbratio * P_chos 
				* ((double)splitnum) / f_ui / P_alloc * jacobi;

			/*std::cout<<"Split"<<std::endl;
			std::cout<<"densityratio"<<std::endl;
			std::cout<<densityratio<<std::endl;
			std::cout<<"weightratio"<<std::endl;
			std::cout<<weightratio<<std::endl;
			std::cout<<"P_chos"<<std::endl;
			std::cout<<P_chos<<std::endl;
			std::cout<<"splitnum"<<std::endl;
			std::cout<<splitnum<<std::endl;
			std::cout<<"f_ui"<<std::endl;
			std::cout<<f_ui<<std::endl;
			std::cout<<"P_alloc"<<std::endl;
			std::cout<<P_alloc<<std::endl;
			std::cout<<"Jacobi"<<std::endl;
			std::cout<<jacobi<<std::endl;*/
			//std::cout<<"Split accepted probability: "<<std::endl;
			return f_fmin(AP,1.0);
		}
}

double MCMCEnv::apMerge(const TreeMergeSet::value_type &mergePair, const TreeSet &splitSetsAfterMerge,
	const long mergesetsrows, const long splitnumaftermerge, const double P_alloc, const double f_ui,
	const MCMCEnv &oldenv) const {

		double densityratio, modelratio, bdratio; 
		double weightratio = 1.0;
		double jacobi = 1.0;
		double P_chos;
		double AP;
		bool NULLset = false;
		//cout << "Mergepair: first = " << mergePair.first << "; second = "
		//	<< mergePair.second << endl;
		const ClusterTree &oldparent = oldenv.getTreeFromID(mergePair.first), 
			&oldchild = oldenv.getTreeFromID(mergePair.second),
			&newparent = getTreeFromID(mergePair.first);
		unsigned long time = oldchild.born_time;

		if((!mergesetsrows) || (!splitnumaftermerge)){
			return 0.0;
		}else{
			densityratio = exp(calcLogDensity() - oldenv.calcLogDensity());
			/*std::cout<<"newz"<<std::endl;
			std::cout<<newz<<std::endl;
			std::cout<<"newweight"<<std::endl;
			std::cout<<newweight<<std::endl;
			std::cout<<"NEW DENSITY"<<std::endl;
			std::cout<<zw_density(newz,newweight,mu1,mu0,sigma0,sigma1,beta0,beta1,deltar)<<std::endl;
			std::cout<<"OLD DENSITY"<<std::endl;
			std::cout<<density(mu1,mu0,sigma0,sigma1,beta0,beta1,deltar)<<std::endl;*/
            
			for(unsigned long i = time; i < NumOfTP; i++){
				if(oldparent.weights[i] > SMALLNUM && oldchild.weights[i] > SMALLNUM ){
					weightratio *= pow(newparent.weights[i], alpha - 1) *
					    betaf(alpha, ((double) getNoZeroWeights(time)) * alpha) 
						/ pow(oldparent.weights[i], alpha - 1) 
						/ pow(oldchild.weights[i], alpha - 1);
					jacobi /= newparent.weights[i];
			
				}

			}
			modelratio = 1.0;
			bdratio = bk / (1.0 - bk);
			try {
				P_chos = oldenv.calcPChos(mergePair, NULLset, splitSetsAfterMerge);
			} catch(std::logic_error &e) {
				cout << "Logic error catched calculating P_chos." << endl;
				throw e;
			}

		}


		AP = densityratio * weightratio * modelratio * bdratio * P_alloc
			/ ((double)splitnumaftermerge) * f_ui / P_chos * jacobi;

		    /*std::cout<<"Merge"<<std::endl;
			std::cout<<"densityratio"<<std::endl;
			std::cout<<densityratio<<std::endl;
			std::cout<<"weightratio"<<std::endl;
			std::cout<<weightratio<<std::endl;
			std::cout<<"P_chos"<<std::endl;
			std::cout<<P_chos<<std::endl;
			std::cout<<"splitnumaftermerge"<<std::endl;
			std::cout<<splitnumaftermerge<<std::endl;
			std::cout<<"f_ui"<<std::endl;
			std::cout<<f_ui<<std::endl;
			std::cout<<"P_alloc"<<std::endl;
			std::cout<<P_alloc<<std::endl;
			std::cout<<"Jacobi"<<std::endl;
			std::cout<<jacobi<<std::endl;
			std::cout<<"Merge accepted probability: "<<std::endl;*/

		return f_fmin(AP,1.0);
}

double MCMCEnv::apBirth(const TreeSet::value_type &splitPair, const long splitnumafterbirth,
	const double weightratio, const double jacobi, const double f_wstar,
	const MCMCEnv &oldenv) const {
		double densityratio, modelratio;
		double AP = 1.0;
		double dbratio = 1.0;
		long i;
		if(splitnumafterbirth == 0){
			return 0.0;
		}else{
			densityratio = exp(calcLogDensity() - oldenv.calcLogDensity());

			// The ratio of f(Tree_new) and f(Tree_old).
			// If we set the same unchange and change probability, then it is equal to 1.0; 
			modelratio = 1.0;
			// The ratio of d_new and b_old, here dbratio = 1.0, because d_new = b_old = 0.5.
			dbratio = (1.0 - bk) / bk;

			AP = densityratio * weightratio * modelratio * dbratio * jacobi
				/ (double) splitnumafterbirth / f_wstar;

			/*std::cout<<"densityratio"<<std::endl;
			std::cout<<densityratio<<std::endl;
			std::cout<<"weightratio"<<std::endl;
			std::cout<<weightratio<<std::endl;
			std::cout<<"splitnumafterbirth"<<std::endl;
			std::cout<<splitnumafterbirth<<std::endl;
			std::cout<<"f_wstar"<<std::endl;
			std::cout<<f_wstar<<std::endl;
			std::cout<<"Jacobi"<<std::endl;
			std::cout<<jacobi<<std::endl;*/
			return f_fmin(AP,1.0);
		}
}

double MCMCEnv::apDeath(const TreeMergeSet::value_type &mergePair, const long emptynumbeforedeath,
	const double weightratio, const double jacobi, const double f_wstar, 
	const MCMCEnv &oldenv) const {
		double densityratio,modelratio,bdratio;
		double AP;

		if(emptynumbeforedeath == 0){
			return 0.0;
		}else{
			densityratio = exp(calcLogDensity() / oldenv.calcLogDensity());
			modelratio = 1.0;
			bdratio = bk / (1.0 - bk);
		}

		AP = densityratio * weightratio * modelratio * bdratio 
			* f_wstar * emptynumbeforedeath * jacobi;

		return f_fmin(AP,1.0);
}

unsigned long MCMCEnv::getClusterNumber() const {
	// get the number of trees
	return MapClusterTrees.size();
}

unsigned long MCMCEnv::getNonEmptyClusterNumber() const {
	// get the number of trees that are not empty throughout the time
	unsigned long count = 0;
	for(TreeContainer::const_iterator itor = MapClusterTrees.begin();
		itor != MapClusterTrees.end(); itor++) {
			if(itor->second.getSampleNum()) {
				count++;
			}
	}
	return count;
}

unsigned long MCMCEnv::getClusterNumber(unsigned long time) const {
	// get the number of trees at time t
	unsigned long count = 0;
	for(TreeContainer::const_iterator itor = MapClusterTrees.begin();
		itor != MapClusterTrees.end(); itor++) {
			if(itor->second.born_time <= time) {
				count++;
			}
	}
	return count;
}

unsigned long MCMCEnv::getNonEmptyClusterNumber(unsigned long time) const {
	// get the number of trees that are not empty throughout the time
	unsigned long count = 0;
	for(TreeContainer::const_iterator itor = MapClusterTrees.begin();
		itor != MapClusterTrees.end(); itor++) {
			if(itor->second.getSampleNum(time)) {
				count++;
			}
	}
	return count;
}

void MCMCEnv::sampleWeight() {

	double wnum;
	std::vector<long> midv;
	for(unsigned long t = 0; t < NumOfTP; t++) {
		
		wnum = 0.0;
		for(TreeContainer::iterator itor = MapClusterTrees.begin();
			itor != MapClusterTrees.end(); itor++) {
				
				if(itor->second.born_time >= t) {
					itor->second.weights[t] = ran_gamma(alpha 
						+ itor->second.getSampleNum(t), shape);
					wnum += itor->second.weights[t];
					//fnum = z.tflagnum(flag,t+1);
					//weight.setValue(t,flag-1,);
					//wnum += weight.getValue(t,flag-1);
				}
		}

		// normalize all weights
		for(TreeContainer::iterator itor = MapClusterTrees.begin();
			itor != MapClusterTrees.end(); itor++) {
				if(itor->second.born_time >= t) {
					if(wnum > SMALLNUM) {
						itor->second.weights[t] = itor->second.weights[t] / wnum;
					} else {
						itor->second.weights[t] = 1.0;
					}
				}
		}
		//midv.clear();
	}

}

void MCMCEnv::sampleTao() {

	long coin2, coin3;

	TaoSet newTao = Tao;

	if(ran_ber(0.5)) {
		coin2 = ran_iunif(0, newTao.size() - 1);
		newTao[coin2] = !newTao[coin2]; //1. Change value.
	} else {
		coin2 = ran_iunif(0, newTao.size() - 1);
		coin3 = ran_iunif(0, newTao.size() - 2);
		if(coin3 >= coin2){
			coin3++;
		}
		bool tao_mid = newTao[coin2];
		newTao[coin2] = newTao[coin3];
		newTao[coin3] = tao_mid;          //or 2. Swap;
	}

	double acceptedp = f_fmin(1.0, exp(calcLogDensity(newTao) - calcLogDensity()));

	if(ran_ber(acceptedp)){
		Tao = newTao;
	} 

	/*std::cout<<"Tao"<<std::endl;
	for(i=0; i<tao_length; i++)
	std::cout<<tao.at(i)<<' ';
	std::cout<<std::endl;*/

}

void MCMCEnv::sampleZ() {
	long k,l,midnum;
	std::vector<unsigned long long> flagl;
	std::vector<double> prob_z;
	//ClusterFlags z_mid = z;
	// reset the first timepoint to root_ID
	for(unsigned long j = 0; j < Flags.cols(0); j++) {
		Flags(0, j) = root_ID;
	}

	for(unsigned long t = 1; t < Flags.rows(); t++){
		
		for(TreeContainer::iterator itor = MapClusterTrees.begin();
			itor != MapClusterTrees.end(); itor++) {
				if(itor->second.weights[t] > SMALLNUM) {
					flagl.push_back(itor->second.ID);
				}
		}

		for(unsigned long j = 0; j < Flags.cols(t); j++){
			for(std::vector<unsigned long long>::const_iterator itor = flagl.begin();
				itor != flagl.end(); itor++) {
					Flags(t, j) = *itor;
					prob_z.push_back(calcLogDensity());
			}

			Flags(t, j) = ran_num_log(prob_z, flagl);

			//for(k=0; k<flagl.size(); k++){
			//	z(i,j) = flagl.at(k);
			//	prob_z.push_back(z_density(z, mu1, mu0, sigma0, sigma1, beta0, beta1, deltar));
			//	// optimize?
			//		
			//}
			//z(i,j) = ran_num(prob_z,flagl);
			//z_mid(i,j) = z(i,j);
			/*std::cout<<"Data"<<"("<<i<<","<<j<<")"<<std::endl;
				for(l=0; l<flagl.size(); l++)
			std::cout<<prob_z.at(l)<<' ';
			std::cout<<std::endl;*/
			/*if(i==3&&j==0){
				for(l=0; l<flagl.size(); l++)
				    std::cout<<prob_z.at(l)<<' ';
				std::cout<<std::endl;
			}*/
				
			prob_z.clear();
		}	 
		//flagl.clear();
	}
	// Do we need to reflag the cluster indicators?
	//z.reflag();
	/*std::cout<<"Sampled z"<<std::endl;
	std::cout<<z<<std::endl;*/
}

double MCMCEnv::treeSummary() const {
	// use binary coding for all the trees
	double value = 0;
	for(TreeContainer::const_iterator itor = MapClusterTrees.begin();
		itor != MapClusterTrees.end(); itor++) {
			value += pow(2, (double) itor->first);
	}
	return value;
}

ostream &MCMCEnv::writeTree(ostream &os) const {
	os << "[] Tree was born;" << endl 
		<< "() A new Tree with this ID is born from the current tree." << endl;
	deque<unsigned long long> IdToShow;
	IdToShow.push_back(root_ID);
	try {
		while(!IdToShow.empty()) {
			const ClusterTree &currTree = getTreeFromID(IdToShow.front());
			IdToShow.pop_front();
			for(unsigned long t = 0; t < NumOfTP; t++) {
				if(t < currTree.born_time) {
					os << "   " << setfill(' ') << setw(TREE_ID_SIZE + 2) << ' ';
				} else if(t == currTree.born_time) {
					os << "   [" << setfill(' ') << setw(TREE_ID_SIZE) << currTree.ID << "]";
				} else {
					if(currTree.getChildID(t)) {
						os << " - (" << setfill(' ') << setw(TREE_ID_SIZE) << currTree.getChildID(t) << ")";
						IdToShow.push_back(currTree.getChildID(t));
					} else {
						os << " - " << setfill('-') << setw(TREE_ID_SIZE) << '-';
					}
				}
			}
			os << setfill(' ') << endl;
		}
	} catch(std::logic_error &e) {
		cout << "Logic error is caught in writeTree." << endl;
		throw e;
	}
	return os;
}

ostream &MCMCEnv::writeTao(ostream &os) const {
	for(unsigned long i = 0; i < NumOfGenes; i++) {
		os << (Tao[i]? '1': '0') << ' ';
	}
	return os << std::endl;
}

ostream &MCMCEnv::writeFlags(ostream &os) const {
	return os << Flags;
}

ostream &MCMCEnv::writeWeights(ostream &os) const {
	for(MCMCEnv::TreeContainer::const_iterator itor = MapClusterTrees.begin();
		itor != MapClusterTrees.end(); itor++) {
			itor->second.writeWeights(os);
	}
	return os;
}

ostream &MCMCEnv::writeStatus(ostream &os) const {
	os<<"Cluster proportions in each cluster: "<<std::endl;
	writeWeights(os);
	os<<std::endl;
	os<<"Featureed genes: "<<std::endl;
	writeTao(os);
	os << endl;
	os<<"Cluster index: "<<std::endl;
	writeFlags(os);
	os<<std::endl;
	os<<"Tree: "<<std::endl;
	writeTree(os);
	os<<std::endl;
	return os;
}

ostream &operator<<(ostream &os, const MCMCEnv &env) {
	long i_t = MCMCEnv::NumOfTP;
	long i_g = MCMCEnv::NumOfGenes;
	int i;
	os<<"Time length:"<<std::endl;
	os<<i_t;
	os<<std::endl;
	os<<"Gene number:"<<std::endl;
	os<<i_g;
	os<<std::endl;
	os<<"Data number:"<<std::endl;
	os<<MCMCEnv::getDataNum();
	os<<std::endl;
	os<<"Data number in each cluster:"<<std::endl;
	for(i=0; i<i_t; i++)
		os<<MCMCEnv::DataNumEachTP[i]<<' ';
	os<<std::endl;
	os<<"Cluster number in each cluster:"<<std::endl;
	for(i=0; i<i_t; i++)
		os<<env.getClusterNumber(i)<<' ';
	os<<std::endl;
	os<<"The original data: "<<std::endl;
	os << env.Data;
	os<<std::endl;

	return os;
}

#undef SMALLNUM
#undef TREE_ID_SIZE